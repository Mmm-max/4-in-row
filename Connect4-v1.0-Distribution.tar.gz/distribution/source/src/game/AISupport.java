package game;

public interface AISupport {
}
