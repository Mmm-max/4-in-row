package game;

public interface GameRestartListener {
    void gameRestart();
    void exit();
}
