package GUI;

public interface ChoosePlayersListener {
    public void onPlayersChosen(String player1, String player2);
}
