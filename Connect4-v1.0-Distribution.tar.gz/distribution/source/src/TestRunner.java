//import org.junit.runner.RunWith;
//import org.junit.runners.Suite;
//
//@RunWith(Suite.class)
//@Suite.SuiteClasses({
//        BoardTest.class, // Добавляем класс с тестами Board
//        // Другие классы с тестами, если есть
//})
//
//public class TestRunner {
//
//}
